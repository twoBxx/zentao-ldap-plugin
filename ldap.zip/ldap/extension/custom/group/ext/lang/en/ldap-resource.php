<?php

$lang->resource->ldap = new stdclass();
$lang->resource->ldap->index = 'common'; 
$lang->resource->ldap->setting = 'setting';