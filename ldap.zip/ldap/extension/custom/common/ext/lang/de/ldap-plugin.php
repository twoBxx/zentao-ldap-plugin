<?php
$lang->ldap = new stdclass();

$lang->navGroup->ldap = 'admin';
