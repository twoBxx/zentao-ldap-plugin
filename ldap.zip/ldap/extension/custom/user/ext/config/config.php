<?php
// ldap 登录需要原始密码
$config->notMd5Pwd = true;
